"""
vault_manager extension package.
"""
