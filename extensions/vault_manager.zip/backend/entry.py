"""
Vault Manager extension entry point
"""
import json
from typing import Any, Dict

from ic import call, Principal
from kybra import Async
from kybra_simple_logging import get_logger

logger = get_logger("extensions.vault_manager")

# Use appropriate ID based on environment - this will be updated at deployment time
VAULT_CANISTER_ID = "ekdcf-yiaaa-aaaah-ardsq-cai"  # Production ID


async def _call_vault(method: str, args: Any = None) -> Dict:
    """Helper function to call the vault canister"""
    try:
        # Convert args from JSON string if provided
        params = json.loads(args) if args else {}
        
        # Call the vault canister
        result = await call(Principal.from_str(VAULT_CANISTER_ID), method, params)
        
        # Format the response
        return {"success": True, "data": result}
    except Exception as e:
        logger.error(f"Error calling vault.{method}: {str(e)}")
        return {"success": False, "error": str(e)}


def get_balance(args: str) -> Async[str]:
    """Get user's vault balance"""
    logger.info(f"vault_manager.get_balance called with args: {args}")
    result = yield _call_vault("get_balance", args)
    return json.dumps(result)


def get_status(args: str) -> Async[str]:
    """Get vault status"""
    logger.info(f"vault_manager.get_status called with args: {args}")
    result = yield _call_vault("get_status", args)
    return json.dumps(result)


def get_transactions(args: str) -> Async[str]:
    """Get user's transaction history"""
    logger.info(f"vault_manager.get_transactions called with args: {args}")
    result = yield _call_vault("get_transactions", args)
    return json.dumps(result)


def transfer(args: str) -> Async[str]:
    """Transfer tokens to another user"""
    logger.info(f"vault_manager.transfer called with args: {args}")
    result = yield _call_vault("transfer", args)
    return json.dumps(result)
