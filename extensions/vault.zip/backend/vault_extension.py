from typing import Any, Dict, Optional

# These imports will be resolved when the extension is installed in the realm project
try:
    import core.candid_types_vault as vault_candids
    from core.extensions import Extension, ExtensionPermission, extension_registry
    from kybra import CallResult, Principal, ic
    from kybra_simple_logging import get_logger
    
    logger = get_logger("extensions.vault_extension")
    MOCK_MODE = False
except ImportError:
    # Mock implementations for testing outside the realm environment
    print("Warning: Running in mock mode")
    MOCK_MODE = True
    
    class Extension:
        def __init__(self, name, description, required_permissions):
            self.name = name
            self.description = description
            self.required_permissions = required_permissions
            self.entry_points = {}
            
        def register_entry_point(self, name, func):
            self.entry_points[name] = func
    
    class ExtensionPermission:
        READ_VAULT = "read_vault"
        TRANSFER_TOKENS = "transfer_tokens"
    
    class Principal:
        @staticmethod
        def from_str(s):
            return s
    
    def get_logger(name):
        class MockLogger:
            def info(self, msg): print(f"INFO [{name}]: {msg}")
            def error(self, msg): print(f"ERROR [{name}]: {msg}")
        return MockLogger()
    
    logger = get_logger("extensions.vault_extension")
    extension_registry = None


class VaultExtension(Extension):
    """
    Vault Extension for managing vault balances and transfers
    """

    def __init__(self, vault_canister_principal: str = None):
        super().__init__(
            name="vault_extension",
            description="Manage vault balances and transfers",
            required_permissions=[
                ExtensionPermission.READ_VAULT,
                ExtensionPermission.TRANSFER_TOKENS,
            ],
        )

        self.vault_canister_principal = vault_canister_principal or "aaaaa-aa"  # Default placeholder
        self._vault = None

        # Register entry points
        self.register_entry_point("get_balance", self.get_balance)
        self.register_entry_point("get_transactions", self.get_transactions)
        self.register_entry_point("transfer", self.transfer)
        self.register_entry_point("get_status", self.get_status)

        logger.info(f"VaultExtension initialized with vault principal: {vault_canister_principal}")

    async def get_balance(self, principal_id: Optional[str] = None) -> Dict[str, Any]:
        """Get balance for a principal (defaults to caller)"""
        if MOCK_MODE:
            # Return mock data for testing
            return {
                "success": True,
                "balance": 1000,
                "token": "ICP",
                "principal_id": principal_id or "2vxsx-fae",
            }
            
        try:
            target_principal = (
                Principal.from_str(principal_id) if principal_id else ic.id()
            )

            # In a real implementation, this would call the vault canister
            # For this example, we'll return mock data
            return {
                "success": True,
                "balance": 1000,
                "token": "ICP",
                "principal_id": str(target_principal),
            }
        except Exception as e:
            logger.error(f"Error in get_balance: {str(e)}")
            return {"success": False, "error": str(e)}

    async def get_transactions(
        self, limit: int = 10, offset: int = 0
    ) -> Dict[str, Any]:
        """Get transaction history for the caller"""
        if MOCK_MODE:
            # Return mock data for testing
            return {
                "success": True,
                "transactions": [
                    {
                        "id": "tx1",
                        "timestamp": 1621459200,
                        "from": "2vxsx-fae",
                        "to": "3vxsx-fae",
                        "amount": 100,
                        "status": "completed",
                        "memo": "Test transaction 1"
                    },
                    {
                        "id": "tx2",
                        "timestamp": 1621459100,
                        "from": "3vxsx-fae",
                        "to": "2vxsx-fae",
                        "amount": 50,
                        "status": "completed",
                        "memo": "Test transaction 2"
                    }
                ],
                "total": 2
            }
            
        try:
            # In a real implementation, this would call the vault canister
            # For this example, we'll return mock data
            return {
                "success": True,
                "transactions": [
                    {
                        "id": "tx1",
                        "timestamp": 1621459200,
                        "from": "2vxsx-fae",
                        "to": "3vxsx-fae",
                        "amount": 100,
                        "status": "completed",
                        "memo": "Test transaction 1"
                    },
                    {
                        "id": "tx2",
                        "timestamp": 1621459100,
                        "from": "3vxsx-fae",
                        "to": "2vxsx-fae",
                        "amount": 50,
                        "status": "completed",
                        "memo": "Test transaction 2"
                    }
                ],
                "total": 2
            }
        except Exception as e:
            logger.error(f"Error in get_transactions: {str(e)}")
            return {"success": False, "error": str(e)}

    async def transfer(
        self, to_principal_id: str, amount: int, memo: str = ""
    ) -> Dict[str, Any]:
        """Transfer tokens to another principal"""
        if MOCK_MODE:
            # Return mock data for testing
            return {
                "success": True,
                "transaction_id": "mock-tx-id"
            }
            
        try:
            # In a real implementation, this would call the vault canister
            # For this example, we'll return mock data
            return {
                "success": True,
                "transaction_id": "mock-tx-id"
            }
        except Exception as e:
            logger.error(f"Error in transfer: {str(e)}")
            return {"success": False, "error": str(e)}

    async def get_status(self) -> Dict[str, Any]:
        """Get vault status information"""
        if MOCK_MODE:
            # Return mock data for testing
            return {
                "success": True,
                "name": "Test Vault",
                "token": "ICP",
                "version": "1.0.0",
                "cycles": 1000000,
                "total_supply": 10000000,
                "accounts": 42
            }
            
        try:
            # In a real implementation, this would call the vault canister
            # For this example, we'll return mock data
            return {
                "success": True,
                "name": "Test Vault",
                "token": "ICP",
                "version": "1.0.0",
                "cycles": 1000000,
                "total_supply": 10000000,
                "accounts": 42
            }
        except Exception as e:
            logger.error(f"Error in get_status: {str(e)}")
            return {"success": False, "error": str(e)}


def init_vault_extension(vault_canister_principal: Optional[str] = None) -> None:
    """Initialize and register the VaultExtension extension"""
    if MOCK_MODE:
        print("Mock mode: init_vault_extension called")
        return
        
    extension = VaultExtension(vault_canister_principal)
    extension_registry.register_extension(extension)

    # Grant required permissions
    extension_registry.grant_permission("vault_extension", ExtensionPermission.READ_VAULT)
    extension_registry.grant_permission(
        "vault_extension", ExtensionPermission.TRANSFER_TOKENS
    )

    logger.info("VaultExtension registered and permissions granted")


# For testing the extension outside the realm environment
if __name__ == "__main__":
    print("Testing VaultExtension in mock mode")
    ext = VaultExtension()
    import asyncio
    
    async def test():
        balance = await ext.get_balance()
        print("Balance:", balance)
        
        txs = await ext.get_transactions()
        print("Transactions:", txs)
        
        status = await ext.get_status()
        print("Status:", status)
        
        transfer = await ext.transfer("3vxsx-fae", 100, "Test transfer")
        print("Transfer:", transfer)
    
    asyncio.run(test())
