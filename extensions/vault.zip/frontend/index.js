import VaultExtension from './VaultExtension.svelte';
import BalanceView from './BalanceView.svelte';
import TransferForm from './TransferForm.svelte';
import * as utils from './utils';

// Export components
export {
  VaultExtension,
  BalanceView,
  TransferForm,
  utils
};

// Extension metadata for the marketplace
export const metadata = {
  id: 'vault-extension',
  name: 'Vault Extension',
  description: 'Manage vault balances and transfers',
  version: '1.0.0',
  icon: 'wallet',
  author: 'Smart Social Contracts Team',
  permissions: ['read_vault', 'transfer_tokens']
};

// Main component is the default export
export default VaultExtension;
