<script>
  import { onMount } from 'svelte';
  import { formatNumber } from '../utils';
  
  export let balance = null;
  export let loading = false;
  export let onRefresh = () => {};
  
  // Format the balance with appropriate precision
  $: formattedBalance = balance ? formatNumber(balance.balance) : '0';
  $: tokenSymbol = balance?.token || 'ICP';
  $: principalId = balance?.principalId || '';
</script>

<div class="balance-card p-4 bg-white rounded-lg shadow-md">
  <div class="flex items-center justify-between mb-4">
    <h3 class="text-lg font-bold text-gray-800">Your Balance</h3>
    <button 
      on:click={onRefresh} 
      class="text-blue-500 hover:text-blue-700"
      disabled={loading}
    >
      {#if loading}
        <span class="loading loading-spinner loading-xs"></span>
      {:else}
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
        </svg>
      {/if}
    </button>
  </div>
  
  {#if balance}
    <div class="flex flex-col">
      <div class="text-3xl font-bold text-gray-900 mb-1">
        {formattedBalance} <span class="text-xl">{tokenSymbol}</span>
      </div>
      <div class="text-xs text-gray-500 truncate">
        Principal ID: {principalId}
      </div>
    </div>
  {:else if loading}
    <div class="flex justify-center py-4">
      <span class="loading loading-spinner loading-md"></span>
    </div>
  {:else}
    <div class="text-gray-500 py-4">
      Balance information unavailable
    </div>
  {/if}
</div>
