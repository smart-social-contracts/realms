<script>
  export let onTransfer = async (recipient, amount, memo) => {};
  export let loading = false;
  export let error = '';
  export let success = false;
  
  let recipient = '';
  let amount = '';
  let memo = '';
  
  // Handle form submission
  async function handleSubmit() {
    if (!recipient || !amount) return;
    
    // Convert amount to integer (assuming the smallest unit)
    const amountValue = parseFloat(amount) * 100_000_000; // Converting to e8s for ICP
    
    await onTransfer(recipient, Math.floor(amountValue), memo);
  }
  
  // Reset the form
  function resetForm() {
    recipient = '';
    amount = '';
    memo = '';
    success = false;
    error = '';
  }
</script>

<div class="transfer-form p-4 bg-white rounded-lg shadow-md">
  <h3 class="text-lg font-bold text-gray-800 mb-4">Transfer Tokens</h3>
  
  <form on:submit|preventDefault={handleSubmit} class="space-y-4">
    <div>
      <label for="recipient" class="block text-sm font-medium text-gray-700 mb-1">
        Recipient Principal ID
      </label>
      <input
        id="recipient"
        type="text"
        bind:value={recipient}
        placeholder="e.g., 2vxsx-fae"
        required
        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        disabled={loading}
      />
    </div>
    
    <div>
      <label for="amount" class="block text-sm font-medium text-gray-700 mb-1">
        Amount
      </label>
      <div class="relative">
        <input
          id="amount"
          type="number"
          bind:value={amount}
          step="0.00000001"
          min="0"
          placeholder="0.0"
          required
          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          disabled={loading}
        />
        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
          <span class="text-gray-500">ICP</span>
        </div>
      </div>
    </div>
    
    <div>
      <label for="memo" class="block text-sm font-medium text-gray-700 mb-1">
        Memo (Optional)
      </label>
      <input
        id="memo"
        type="text"
        bind:value={memo}
        placeholder="Add a note about this transfer"
        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        disabled={loading}
      />
    </div>
    
    {#if error}
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <p class="text-sm">{error}</p>
      </div>
    {/if}
    
    {#if success}
      <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <p class="text-sm">Transfer completed successfully!</p>
        <button 
          type="button" 
          on:click={resetForm} 
          class="mt-2 text-sm text-green-700 underline"
        >
          Make another transfer
        </button>
      </div>
    {:else}
      <button
        type="submit"
        class="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        disabled={loading || !recipient || !amount}
      >
        {#if loading}
          <span class="loading loading-spinner loading-xs mr-2"></span>
          Processing...
        {:else}
          Send Tokens
        {/if}
      </button>
    {/if}
  </form>
</div>
