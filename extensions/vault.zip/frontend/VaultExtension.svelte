<script>
  import { onMount } from 'svelte';
  import BalanceView from './components/BalanceView.svelte';
  import TransferForm from './components/TransferForm.svelte';
  
  // Component state
  let loading = true;
  let balanceLoading = false;
  let transferLoading = false;
  let error = '';
  let transferError = '';
  let transferSuccess = false;
  let balanceData = null;
  
  // This will be provided by the realm application when the extension is installed
  let backend = null;
  
  onMount(async () => {
    // Try to access the backend API from the global context
    // In a real implementation, this would be injected by the host application
    if (window.realm && window.realm.backend) {
      backend = window.realm.backend;
    } else {
      console.warn('Realm backend not found, using mock mode');
      // Create mock implementation for testing
      backend = {
        async call_extension_api(args) {
          console.log('Mock call_extension_api', args);
          
          // Simulate network delay
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          if (args.extension_name === 'vault_extension') {
            if (args.entry_point === 'get_balance') {
              return {
                success: true,
                data: {
                  balance: 1000,
                  token: 'ICP',
                  principal_id: '2vxsx-fae'
                }
              };
            } else if (args.entry_point === 'transfer') {
              return {
                success: true,
                data: {
                  transaction_id: 'mock-tx-id'
                }
              };
            }
          }
          
          return { success: false, error: 'Method not implemented' };
        }
      };
    }
    
    await refreshBalance();
  });
  
  // Get balance for the current user
  async function refreshBalance() {
    balanceLoading = true;
    error = '';
    
    try {
      const response = await backend.call_extension_api({
        extension_name: 'vault_extension',
        entry_point: 'get_balance',
        args: [],
        kwargs: {}
      });
      
      if (response.success) {
        balanceData = {
          balance: response.data.balance,
          token: response.data.token,
          principalId: response.data.principal_id
        };
      } else {
        error = `Failed to get balance: ${response.error}`;
        console.error(error);
      }
    } catch (err) {
      error = `Error: ${err.message}`;
      console.error('Error fetching balance:', err);
    } finally {
      balanceLoading = false;
      loading = false;
    }
  }
  
  // Transfer tokens to another principal
  async function handleTransfer(recipient, amount, memo) {
    transferLoading = true;
    transferError = '';
    transferSuccess = false;
    
    try {
      const response = await backend.call_extension_api({
        extension_name: 'vault_extension',
        entry_point: 'transfer',
        args: [],
        kwargs: {
          to_principal_id: recipient,
          amount: amount,
          memo: memo
        }
      });
      
      if (response.success) {
        transferSuccess = true;
        // Refresh balance after successful transfer
        await refreshBalance();
      } else {
        transferError = `Transfer failed: ${response.error}`;
        console.error(transferError);
      }
    } catch (err) {
      transferError = `Error: ${err.message}`;
      console.error('Error during transfer:', err);
    } finally {
      transferLoading = false;
    }
  }
</script>

<div class="vault-extension p-4">
  <h2 class="text-2xl font-bold mb-6">Vault Manager</h2>
  
  {#if error}
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
      <p>{error}</p>
    </div>
  {/if}
  
  <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <BalanceView 
      balance={balanceData} 
      loading={balanceLoading} 
      onRefresh={refreshBalance} 
    />
    
    <TransferForm 
      onTransfer={handleTransfer} 
      loading={transferLoading} 
      error={transferError} 
      success={transferSuccess} 
    />
  </div>
</div>
