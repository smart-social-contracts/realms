/**
 * Format a number with thousands separators
 * @param {number} value - The number to format
 * @param {number} decimals - Number of decimal places
 * @returns {string} Formatted number
 */
export function formatNumber(value, decimals = 8) {
  if (value === undefined || value === null) return '0';
  
  const formatter = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
  
  return formatter.format(value);
}

/**
 * Format a timestamp to a readable date
 * @param {number} timestamp - Unix timestamp
 * @returns {string} Formatted date
 */
export function formatDate(timestamp) {
  if (!timestamp) return '';
  
  const date = new Date(timestamp * 1000);
  return date.toLocaleString('en-US', {
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

/**
 * Shorten a principal ID for display
 * @param {string} principal - Principal ID
 * @returns {string} Shortened principal
 */
export function shortenPrincipal(principal) {
  if (!principal || principal.length <= 10) return principal;
  return `${principal.substring(0, 5)}...${principal.substring(principal.length - 5)}`;
}
