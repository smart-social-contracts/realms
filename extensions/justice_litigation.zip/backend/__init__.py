"""
justice_litigation extension package.
"""
