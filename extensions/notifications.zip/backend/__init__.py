"""
notifications extension package.
"""
