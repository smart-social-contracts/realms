"""
LLM Chat extension for Realm backend
"""
