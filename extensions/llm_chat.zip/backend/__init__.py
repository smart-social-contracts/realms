"""
AI assistant extension for Realm backend
"""
